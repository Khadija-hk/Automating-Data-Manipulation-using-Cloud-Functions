import functions_framework
from google.cloud import storage
import pandas as pd

#custom function to carry out df operations
def process_dataframe(df):

  #cleaning df
  new_df = df.drop_duplicates()

  q1 = df.head(5)
  print("Head of the file: ")
  print(q1)

  q2 = df.tail(3)
  print("Tail of the file: ")
  print(q2)

  row, cols = df.shape
  print(f"Num of rows: {row}")
  print(f"Num of cols: {cols}")

  print(f"Data type of each col:\n{df.dtypes}")

  memory_usage = df.memory_usage(deep=True).sum() / (1024 ** 2)  # Convert bytes to megabytes
  print("Memory usage of the DataFrame:", memory_usage, "MB")

  print(df.describe())

  #Total number of app titles which contain ‘astrology’
  total_app_astrology = df[df['App'].str.contains('astrology', case = False)]
  number_astrology = total_app_astrology['App'].count()
  print(f"Total number of app titles which contain ‘astrology’: {number_astrology}")

  #Average app rating
  average_rating = df['Rating'].mean()
  print(f"Average app rating: {average_rating}")

  # category getting the highest average rating
  mean_category = df.groupby('Category')['Rating'].mean()
  print(mean_category)

  #Find total number of unique categories
  unique_categories = df['Category'].unique()
  num_unique = len(unique_categories)
  print(f"Number of unique categories: {num_unique}")
  print("Unique Categories:\n","\n".join(unique_categories))

  #total number of app having 5-star rating
  num_5star = len(df[df['Rating'] == 5])
  print(num_5star)

  #average value of reviews
  df['Reviews'] = pd.to_numeric(df['Reviews'], errors='coerce')
  average_reviews = df['Reviews'].mean()
  print(average_reviews)

  #total number of free and paid apps
  type_counts = df['Type'].value_counts()
  num_free = type_counts['Free']
  num_paid = type_counts['Paid']
  print(f"Number of free apps: {num_free}")
  print(f"Number of paid apps: {num_paid}")

  #app has maximum reviews
  maxReviews = df['Reviews'].max()
  print(df[df['Reviews'] == maxReviews]['App'])

  #top 5 apps having highest reviews
  df['Reviews'] = pd.to_numeric(df['Reviews'], errors='coerce')
  sorted_df = df.sort_values(by='Reviews', ascending=False)
  print(sorted_df.head(5))

  #average rating of free and paid apps
  mean_type = df.groupby('Type')['Rating'].mean()
  mean_free = mean_type['Free']
  mean_paid = mean_type['Paid']
  print(f"Average rating of free apps: {mean_free}")
  print(f"Average rating of paid apps: {mean_paid}")

  #top 5 apps having maximum installs
  new_df = df[df['Installs']!= 'Free']
  sort_installs = new_df.sort_values(by = 'Installs', ascending=False)
  print(sort_installs.head(5))

  return new_df

# Triggered by a change in a storage bucket
@functions_framework.cloud_event
def hello_gcs(cloud_event):
    data = cloud_event.data

    event_id = cloud_event["id"]
    event_type = cloud_event["type"]

    bucket = data["bucket"]
    name = data["name"]
    metageneration = data["metageneration"]
    timeCreated = data["timeCreated"]
    updated = data["updated"]

    print(f"Event ID: {event_id}")
    print(f"Event type: {event_type}")
    print(f"Bucket: {bucket}")
    print(f"File: {name}")
    print(f"Metageneration: {metageneration}")
    print(f"Created: {timeCreated}")
    print(f"Updated: {updated}")

    client = storage.Client()
    if name.endswith(".csv"):
      df = pd.read_csv(f"gs://{bucket}/{name}")
      new_df = process_dataframe(df)
      #send to output bucket
      new_df.to_csv(f"gs://apps-data-output/cleaned_data.csv")
    else:
      bucket_conn = client.get_bucket(bucket)
      blob = bucket_conn.blob(name)
      content = blob.download_as_string()
      print(content)
